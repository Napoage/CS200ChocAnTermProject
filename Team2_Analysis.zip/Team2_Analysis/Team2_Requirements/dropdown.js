const carousel = document.querySelector(".carousel");
const prevButton = document.querySelector(".prev-button");
const nextButton = document.querySelector(".next-button");

let slideIndex = 0;

// Event listeners for previous and next buttons
prevButton.addEventListener("click", () => {
    showSlide(slideIndex - 1);
});

nextButton.addEventListener("click", () => {
    showSlide(slideIndex + 1);
});

// Function to show a specific slide
function showSlide(index) {
    if (index < 0) {
        index = carousel.children.length - 1;
    } else if (index >= carousel.children.length) {
        index = 0;
    }

    slideIndex = index;
    const slideWidth = carousel.children[0].offsetWidth;
    carousel.style.transform = `translateX(-${slideWidth * index}px)`;
}
