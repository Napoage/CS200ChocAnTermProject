const letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

document.addEventListener('DOMContentLoaded', function () {
    const specificH1 = document.getElementById("company-name");
    const anonymousSpan = specificH1.querySelector("span");
  const originalText = anonymousSpan.innerText;
  let iterations = 0;

  const interval = setInterval(() => {
    anonymousSpan.innerText = originalText
      .split("")
      .map((letter, index) => {
        if (index < iterations) {
          return originalText[index];
        }

        return letters[Math.floor(Math.random() * 26)];
      })
      .join("");

    if (iterations >= originalText.length) {
      clearInterval(interval);
    }

    iterations += 1 / 20;
  }, 10); // Adjust the interval time as needed (e.g., 100 milliseconds)
  
  anonymousSpan.onmouseover = () => {
    // Reset the iterations when the mouse is over the element
    iterations = 0;
  };
});
