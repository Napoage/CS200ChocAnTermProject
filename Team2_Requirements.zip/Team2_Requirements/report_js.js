const letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

document.addEventListener('DOMContentLoaded', function () {
  const specificH1 = document.getElementById("company-name");
  const anonymousSpan = specificH1.querySelector("span");
  const originalText = anonymousSpan.innerText;
  let iterations = 0;

  // Function to scramble the text
  function scrambleText() {
    iterations = 0;
    const interval = setInterval(() => {
      anonymousSpan.innerText = originalText
        .split("")
        .map((letter, index) => {
          if (index < iterations) {
            return originalText[index];
          }

          return letters[Math.floor(Math.random() * 26)];
        })
        .join("");

      if (iterations >= originalText.length) {
        clearInterval(interval);
      }

      iterations += 1 / 10;
    }, 10);
  }

  // Initial scramble when the page loads
  scrambleText();

  // Rescramble the text every 3 seconds
  setInterval(scrambleText, 3000);
});
