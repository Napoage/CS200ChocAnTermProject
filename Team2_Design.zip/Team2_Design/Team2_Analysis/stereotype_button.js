const stereotype_button = document.getElementById("stereotype_button");

// Add a click event listener to the button
stereotype_button.addEventListener("click", function () {
    // Redirect to the image page when the button is clicked
    window.location.href = "stereotype_page.html";
});