const activity_button = document.getElementById("activity_button");

// Add a click event listener to the button
activity_button.addEventListener("click", function () {
    // Redirect to the image page when the button is clicked
    window.location.href = "activity_page.html";
});