const zoomImage = document.getElementById('zoom-image');
const zoomBox = document.getElementById('zoom-box');
const zoomedImage = document.getElementById('zoomed-image');
const closeZoom = document.getElementById('close-zoom');

zoomImage.addEventListener('click', () => {
    zoomBox.style.display = 'flex'; // Change to flex to center contents
    zoomedImage.src = zoomImage.src;
    zoomedImage.style.width = '100%'; // Reset zoomed image width
    zoomedImage.style.height = '100%'; // Reset zoomed image height
});

closeZoom.addEventListener('click', () => {
    zoomBox.style.display = 'none';
});

zoomBox.addEventListener('click', (e) => {
    if (e.target === zoomBox) {
        zoomBox.style.display = 'none';
    }
});

// Initially, hide the zoom box
zoomBox.style.display = 'none';
